<?php
if ( !defined('WHMCS')) {
    header("Location: ../../index.php");
}
